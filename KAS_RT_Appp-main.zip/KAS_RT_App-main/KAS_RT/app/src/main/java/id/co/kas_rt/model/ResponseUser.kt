package id.co.kas_rt.model



data class ResponseUser(val data: List<DataItem>)
